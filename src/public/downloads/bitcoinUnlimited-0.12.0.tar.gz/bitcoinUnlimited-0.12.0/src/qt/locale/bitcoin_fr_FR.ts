<TS language="fr_FR" version="2.1">
<context>
    <name>AddressBookPage</name>
    <message>
        <source>Create a new address</source>
        <translation>Créer une nouvelle adresse</translation>
    </message>
    <message>
        <source>Copy the currently selected address to the system clipboard</source>
        <translation>Copier l'adresse surlignée dans votre presse-papiers</translation>
    </message>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporter les données de l'onglet courant vers un fichier</translation>
    </message>
    <message>
        <source>&amp;Delete</source>
        <translation>&amp;Supprimer</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Valeurs séparées par des virgules (*.csv)</translation>
    </message>
    </context>
<context>
    <name>AddressTableModel</name>
    <message>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(aucune étiquette)</translation>
    </message>
</context>
<context>
    <name>AskPassphraseDialog</name>
    <message>
        <source>Enter passphrase</source>
        <translation>Entrez la phrase de passe</translation>
    </message>
    <message>
        <source>New passphrase</source>
        <translation>Nouvelle phrase de passe</translation>
    </message>
    <message>
        <source>Repeat new passphrase</source>
        <translation>Répétez la phrase de passe</translation>
    </message>
    <message>
        <source>Encrypt wallet</source>
        <translation>Chiffrer le porte-monnaie</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to unlock the wallet.</source>
        <translation>Cette opération nécessite votre phrase de passe pour déverrouiller le porte-monnaie.</translation>
    </message>
    <message>
        <source>Unlock wallet</source>
        <translation>Déverrouiller le porte-monnaie</translation>
    </message>
    <message>
        <source>This operation needs your wallet passphrase to decrypt the wallet.</source>
        <translation>Cette opération nécessite votre phrase de passe pour décrypter le porte-monnaie.</translation>
    </message>
    <message>
        <source>Decrypt wallet</source>
        <translation>Décrypter le porte-monnaie</translation>
    </message>
    <message>
        <source>Change passphrase</source>
        <translation>Changer la phrase de passe</translation>
    </message>
    <message>
        <source>Confirm wallet encryption</source>
        <translation>Confirmer le chiffrement du porte-monnaie</translation>
    </message>
    <message>
        <source>Wallet encrypted</source>
        <translation>Porte-monnaie chiffré</translation>
    </message>
    <message>
        <source>Wallet encryption failed</source>
        <translation>Le chiffrement du porte-monnaie a échoué</translation>
    </message>
    <message>
        <source>Wallet encryption failed due to an internal error. Your wallet was not encrypted.</source>
        <translation>Le chiffrement du porte-monnaie a échoué en raison d'une erreur interne. Votre porte-monnaie n'a pas été chiffré.</translation>
    </message>
    <message>
        <source>The supplied passphrases do not match.</source>
        <translation>Les phrases de passe entrées ne correspondent pas.</translation>
    </message>
    <message>
        <source>Wallet unlock failed</source>
        <translation>Le déverrouillage du porte-monnaie a échoué</translation>
    </message>
    <message>
        <source>The passphrase entered for the wallet decryption was incorrect.</source>
        <translation>La phrase de passe entrée pour décrypter le porte-monnaie était erronée.</translation>
    </message>
    <message>
        <source>Wallet decryption failed</source>
        <translation>Le décryptage du porte-monnaie a échoué</translation>
    </message>
    </context>
<context>
    <name>BanTableModel</name>
    </context>
<context>
    <name>BitcoinGUI</name>
    <message>
        <source>Synchronizing with network...</source>
        <translation>Synchronisation avec le réseau...</translation>
    </message>
    <message>
        <source>&amp;Overview</source>
        <translation>&amp;Vue d'ensemble</translation>
    </message>
    <message>
        <source>Show general overview of wallet</source>
        <translation>Affiche une vue d'ensemble du porte-monnaie</translation>
    </message>
    <message>
        <source>&amp;Transactions</source>
        <translation>&amp;Transactions</translation>
    </message>
    <message>
        <source>Browse transaction history</source>
        <translation>Permet de parcourir l'historique des transactions</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>Qui&amp;tter</translation>
    </message>
    <message>
        <source>Quit application</source>
        <translation>Quitter l'application</translation>
    </message>
    <message>
        <source>About &amp;Qt</source>
        <translation>À propos de &amp;Qt</translation>
    </message>
    <message>
        <source>Show information about Qt</source>
        <translation>Afficher des informations sur Qt</translation>
    </message>
    <message>
        <source>&amp;Options...</source>
        <translation>&amp;Options...</translation>
    </message>
    <message>
        <source>Backup wallet to another location</source>
        <translation>Sauvegarder le porte-monnaie à un autre emplacement</translation>
    </message>
    <message>
        <source>Change the passphrase used for wallet encryption</source>
        <translation>Modifier la phrase de passe utilisée pour le cryptage du porte-monnaie</translation>
    </message>
    <message>
        <source>Bitcoin</source>
        <translation>Bitcoin</translation>
    </message>
    <message>
        <source>&amp;Send</source>
        <translation>&amp;Envoyer</translation>
    </message>
    <message>
        <source>&amp;File</source>
        <translation>&amp;Fichier</translation>
    </message>
    <message>
        <source>&amp;Settings</source>
        <translation>&amp;Réglages</translation>
    </message>
    <message>
        <source>&amp;Help</source>
        <translation>&amp;Aide</translation>
    </message>
    <message>
        <source>Tabs toolbar</source>
        <translation>Barre d'outils des onglets</translation>
    </message>
    <message>
        <source>Up to date</source>
        <translation>À jour</translation>
    </message>
    <message>
        <source>Catching up...</source>
        <translation>Rattrapage...</translation>
    </message>
    <message>
        <source>Sent transaction</source>
        <translation>Transaction envoyée</translation>
    </message>
    <message>
        <source>Incoming transaction</source>
        <translation>Transaction entrante</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;unlocked&lt;/b&gt;</source>
        <translation>Le porte-monnaie est &lt;b&gt;chiffré&lt;/b&gt; et est actuellement &lt;b&gt;déverrouillé&lt;/b&gt;</translation>
    </message>
    <message>
        <source>Wallet is &lt;b&gt;encrypted&lt;/b&gt; and currently &lt;b&gt;locked&lt;/b&gt;</source>
        <translation>Le porte-monnaie est &lt;b&gt;chiffré&lt;/b&gt; et est actuellement &lt;b&gt;verrouillé&lt;/b&gt;</translation>
    </message>
</context>
<context>
    <name>ClientModel</name>
    </context>
<context>
    <name>CoinControlDialog</name>
    <message>
        <source>Amount:</source>
        <translation>Montant :</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmée</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copier l'adresse</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copier l'étiquette</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copier le montant</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(aucune étiquette)</translation>
    </message>
    </context>
<context>
    <name>EditAddressDialog</name>
    <message>
        <source>Edit Address</source>
        <translation>Éditer l'adresse</translation>
    </message>
    <message>
        <source>&amp;Label</source>
        <translation>&amp;Étiquette</translation>
    </message>
    <message>
        <source>&amp;Address</source>
        <translation>&amp;Adresse</translation>
    </message>
    <message>
        <source>New receiving address</source>
        <translation>Nouvelle adresse de réception</translation>
    </message>
    <message>
        <source>New sending address</source>
        <translation>Nouvelle adresse d'envoi</translation>
    </message>
    <message>
        <source>Edit receiving address</source>
        <translation>Éditer l'adresse de réception</translation>
    </message>
    <message>
        <source>Edit sending address</source>
        <translation>Éditer l'adresse d'envoi</translation>
    </message>
    <message>
        <source>The entered address "%1" is already in the address book.</source>
        <translation>L'adresse fournie « %1 » est déjà présente dans le carnet d'adresses.</translation>
    </message>
    <message>
        <source>Could not unlock wallet.</source>
        <translation>Impossible de déverrouiller le porte-monnaie.</translation>
    </message>
    <message>
        <source>New key generation failed.</source>
        <translation>Échec de la génération de la nouvelle clef.</translation>
    </message>
</context>
<context>
    <name>FreespaceChecker</name>
    </context>
<context>
    <name>HelpMessageDialog</name>
    <message>
        <source>Usage:</source>
        <translation>Utilisation :</translation>
    </message>
    </context>
<context>
    <name>Intro</name>
    </context>
<context>
    <name>OpenURIDialog</name>
    </context>
<context>
    <name>OptionsDialog</name>
    <message>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <source>Automatically open the Bitcoin client port on the router. This only works when your router supports UPnP and it is enabled.</source>
        <translation>Ouvrir le port du client Bitcoin automatiquement sur le routeur. Cela ne fonctionne que si votre routeur supporte l'UPnP et si la fonctionnalité est activée.</translation>
    </message>
    <message>
        <source>Map port using &amp;UPnP</source>
        <translation>Ouvrir le port avec l'&amp;UPnP</translation>
    </message>
    <message>
        <source>&amp;Minimize to the tray instead of the taskbar</source>
        <translation>&amp;Minimiser dans la barre système au lieu de la barre des tâches</translation>
    </message>
    <message>
        <source>M&amp;inimize on close</source>
        <translation>Mi&amp;nimiser lors de la fermeture</translation>
    </message>
    </context>
<context>
    <name>OverviewPage</name>
    <message>
        <source>Form</source>
        <translation>Formulaire</translation>
    </message>
    </context>
<context>
    <name>PaymentServer</name>
    </context>
<context>
    <name>PeerTableModel</name>
    </context>
<context>
    <name>QObject</name>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    </context>
<context>
    <name>QRImageWidget</name>
    </context>
<context>
    <name>RPCConsole</name>
    <message>
        <source>Name</source>
        <translation>Nom</translation>
    </message>
    </context>
<context>
    <name>ReceiveCoinsDialog</name>
    <message>
        <source>&amp;Amount:</source>
        <translation>Montant :</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Étiquette :</translation>
    </message>
    <message>
        <source>&amp;Message:</source>
        <translation>Message :</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copier l'étiquette</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copier le montant</translation>
    </message>
</context>
<context>
    <name>ReceiveRequestDialog</name>
    <message>
        <source>QR Code</source>
        <translation>QR Code</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    </context>
<context>
    <name>RecentRequestsTableModel</name>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(aucune étiquette)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsDialog</name>
    <message>
        <source>Send Coins</source>
        <translation>Envoyer des pièces</translation>
    </message>
    <message>
        <source>Insufficient funds!</source>
        <translation>Fonds insuffisants</translation>
    </message>
    <message>
        <source>Amount:</source>
        <translation>Montant :</translation>
    </message>
    <message>
        <source>Send to multiple recipients at once</source>
        <translation>Envoyer des pièces à plusieurs destinataires à la fois</translation>
    </message>
    <message>
        <source>Balance:</source>
        <translation>Solde :</translation>
    </message>
    <message>
        <source>Confirm the send action</source>
        <translation>Confirmer l'action d'envoi</translation>
    </message>
    <message>
        <source>Confirm send coins</source>
        <translation>Confirmer l'envoi des pièces</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copier le montant</translation>
    </message>
    <message>
        <source>The amount to pay must be larger than 0.</source>
        <translation>Le montant à payer doit être supérieur à 0.</translation>
    </message>
    <message>
        <source>(no label)</source>
        <translation>(aucune étiquette)</translation>
    </message>
    </context>
<context>
    <name>SendCoinsEntry</name>
    <message>
        <source>A&amp;mount:</source>
        <translation>&amp;Montant :</translation>
    </message>
    <message>
        <source>Pay &amp;To:</source>
        <translation>Payer &amp;à :</translation>
    </message>
    <message>
        <source>Enter a label for this address to add it to your address book</source>
        <translation>Entrez une étiquette pour cette adresse afin de l'ajouter à votre carnet d'adresses</translation>
    </message>
    <message>
        <source>&amp;Label:</source>
        <translation>&amp;Étiquette :</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Coller une adresse depuis le presse-papiers</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Message:</source>
        <translation>Message :</translation>
    </message>
    <message>
        <source>Pay To:</source>
        <translation>Payer à :</translation>
    </message>
    </context>
<context>
    <name>ShutdownWindow</name>
    </context>
<context>
    <name>SignVerifyMessageDialog</name>
    <message>
        <source>&amp;Sign Message</source>
        <translation>&amp;Signer le message</translation>
    </message>
    <message>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <source>Paste address from clipboard</source>
        <translation>Coller une adresse depuis le presse-papiers</translation>
    </message>
    <message>
        <source>Alt+P</source>
        <translation>Alt+P</translation>
    </message>
    <message>
        <source>Enter the message you want to sign here</source>
        <translation>Entrez ici le message que vous désirez signer</translation>
    </message>
    <message>
        <source>Sign &amp;Message</source>
        <translation>&amp;Signer le message</translation>
    </message>
    </context>
<context>
    <name>SplashScreen</name>
    <message>
        <source>[testnet]</source>
        <translation>[testnet]</translation>
    </message>
</context>
<context>
    <name>TrafficGraphWidget</name>
    </context>
<context>
    <name>TransactionDesc</name>
    <message>
        <source>Open until %1</source>
        <translation>Ouvert jusqu'à %1</translation>
    </message>
    <message>
        <source>%1/unconfirmed</source>
        <translation>%1/non confirmée</translation>
    </message>
    <message>
        <source>%1 confirmations</source>
        <translation>%1 confirmations</translation>
    </message>
    <message>
        <source>Status</source>
        <translation>État</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Generated</source>
        <translation>Généré</translation>
    </message>
    <message>
        <source>Credit</source>
        <translation>Crédit</translation>
    </message>
    <message>
        <source>Debit</source>
        <translation>Débit</translation>
    </message>
    <message>
        <source>Message</source>
        <translation>Message</translation>
    </message>
    <message>
        <source>Amount</source>
        <translation>Montant</translation>
    </message>
    <message>
        <source>, has not been successfully broadcast yet</source>
        <translation>, n'a pas encore été diffusée avec succès</translation>
    </message>
    <message>
        <source>unknown</source>
        <translation>inconnue</translation>
    </message>
</context>
<context>
    <name>TransactionDescDialog</name>
    <message>
        <source>Transaction details</source>
        <translation>Détails de la transaction</translation>
    </message>
    <message>
        <source>This pane shows a detailed description of the transaction</source>
        <translation>Ce panneau affiche une description détaillée de la transaction</translation>
    </message>
</context>
<context>
    <name>TransactionTableModel</name>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Open until %1</source>
        <translation>Ouvert jusqu'à %1</translation>
    </message>
    <message>
        <source>Confirmed (%1 confirmations)</source>
        <translation>Confirmée (%1 confirmations)</translation>
    </message>
    <message>
        <source>This block was not received by any other nodes and will probably not be accepted!</source>
        <translation>Ce bloc n'a été reçu par aucun autre nœud et ne sera probablement pas accepté !</translation>
    </message>
    <message>
        <source>Generated but not accepted</source>
        <translation>Généré mais pas accepté</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Reçues avec</translation>
    </message>
    <message>
        <source>Received from</source>
        <translation>Reçue de</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Envoyées à</translation>
    </message>
    <message>
        <source>Payment to yourself</source>
        <translation>Paiement à vous-même</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Extraction</translation>
    </message>
    <message>
        <source>(n/a)</source>
        <translation>(indisponible)</translation>
    </message>
    <message>
        <source>Transaction status. Hover over this field to show number of confirmations.</source>
        <translation>État de la transaction. Laissez le pointeur de la souris sur ce champ pour voir le nombre de confirmations.</translation>
    </message>
    <message>
        <source>Date and time that the transaction was received.</source>
        <translation>Date et heure de réception de la transaction.</translation>
    </message>
    <message>
        <source>Type of transaction.</source>
        <translation>Type de transaction.</translation>
    </message>
    <message>
        <source>Amount removed from or added to balance.</source>
        <translation>Montant ajouté au ou enlevé du solde.</translation>
    </message>
</context>
<context>
    <name>TransactionView</name>
    <message>
        <source>All</source>
        <translation>Toutes</translation>
    </message>
    <message>
        <source>Today</source>
        <translation>Aujourd'hui</translation>
    </message>
    <message>
        <source>This week</source>
        <translation>Cette semaine</translation>
    </message>
    <message>
        <source>This month</source>
        <translation>Ce mois</translation>
    </message>
    <message>
        <source>Last month</source>
        <translation>Mois dernier</translation>
    </message>
    <message>
        <source>This year</source>
        <translation>Cette année</translation>
    </message>
    <message>
        <source>Range...</source>
        <translation>Intervalle...</translation>
    </message>
    <message>
        <source>Received with</source>
        <translation>Reçues avec</translation>
    </message>
    <message>
        <source>Sent to</source>
        <translation>Envoyées à</translation>
    </message>
    <message>
        <source>To yourself</source>
        <translation>À vous-même</translation>
    </message>
    <message>
        <source>Mined</source>
        <translation>Extraction</translation>
    </message>
    <message>
        <source>Other</source>
        <translation>Autres</translation>
    </message>
    <message>
        <source>Enter address or label to search</source>
        <translation>Entrez une adresse ou une étiquette à rechercher</translation>
    </message>
    <message>
        <source>Min amount</source>
        <translation>Montant min</translation>
    </message>
    <message>
        <source>Copy address</source>
        <translation>Copier l'adresse</translation>
    </message>
    <message>
        <source>Copy label</source>
        <translation>Copier l'étiquette</translation>
    </message>
    <message>
        <source>Copy amount</source>
        <translation>Copier le montant</translation>
    </message>
    <message>
        <source>Edit label</source>
        <translation>Éditer l'étiquette</translation>
    </message>
    <message>
        <source>Comma separated file (*.csv)</source>
        <translation>Valeurs séparées par des virgules (*.csv)</translation>
    </message>
    <message>
        <source>Confirmed</source>
        <translation>Confirmée</translation>
    </message>
    <message>
        <source>Date</source>
        <translation>Date</translation>
    </message>
    <message>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>Label</source>
        <translation>Étiquette</translation>
    </message>
    <message>
        <source>Address</source>
        <translation>Adresse</translation>
    </message>
    <message>
        <source>ID</source>
        <translation>ID</translation>
    </message>
    <message>
        <source>Range:</source>
        <translation>Intervalle :</translation>
    </message>
    <message>
        <source>to</source>
        <translation>à</translation>
    </message>
</context>
<context>
    <name>UnitDisplayStatusBarControl</name>
    </context>
<context>
    <name>WalletFrame</name>
    </context>
<context>
    <name>WalletModel</name>
    <message>
        <source>Send Coins</source>
        <translation>Envoyer des pièces</translation>
    </message>
</context>
<context>
    <name>WalletView</name>
    <message>
        <source>Export the data in the current tab to a file</source>
        <translation>Exporter les données de l'onglet courant vers un fichier</translation>
    </message>
    <message>
        <source>Backup Wallet</source>
        <translation>Sauvegarder le porte-monnaie</translation>
    </message>
    <message>
        <source>Wallet Data (*.dat)</source>
        <translation>Données de porte-monnaie (*.dat)</translation>
    </message>
    <message>
        <source>Backup Failed</source>
        <translation>La sauvegarde a échoué</translation>
    </message>
    </context>
<context>
    <name>bitcoin-core</name>
    <message>
        <source>Options:</source>
        <translation>Options :</translation>
    </message>
    <message>
        <source>Specify data directory</source>
        <translation>Spécifier le répertoire de données</translation>
    </message>
    <message>
        <source>Accept command line and JSON-RPC commands</source>
        <translation>Accepter les commandes de JSON-RPC et de la ligne de commande</translation>
    </message>
    <message>
        <source>Run in the background as a daemon and accept commands</source>
        <translation>Fonctionner en arrière-plan en tant que démon et accepter les commandes</translation>
    </message>
    <message>
        <source>Send trace/debug info to console instead of debug.log file</source>
        <translation>Envoyer les informations de débogage/trace à la console au lieu du fichier debug.log</translation>
    </message>
    <message>
        <source>Username for JSON-RPC connections</source>
        <translation>Nom d'utilisateur pour les connexions JSON-RPC</translation>
    </message>
    <message>
        <source>Password for JSON-RPC connections</source>
        <translation>Mot de passe pour les connexions JSON-RPC</translation>
    </message>
    <message>
        <source>This help message</source>
        <translation>Ce message d'aide</translation>
    </message>
    <message>
        <source>Loading addresses...</source>
        <translation>Chargement des adresses...</translation>
    </message>
    <message>
        <source>Error loading wallet.dat: Wallet corrupted</source>
        <translation>Erreur lors du chargement de wallet.dat : porte-monnaie corrompu</translation>
    </message>
    <message>
        <source>Error loading wallet.dat</source>
        <translation>Erreur lors du chargement de wallet.dat</translation>
    </message>
    <message>
        <source>Insufficient funds</source>
        <translation>Fonds insuffisants</translation>
    </message>
    <message>
        <source>Loading block index...</source>
        <translation>Chargement de l'index des blocs...</translation>
    </message>
    <message>
        <source>Loading wallet...</source>
        <translation>Chargement du porte-monnaie...</translation>
    </message>
    <message>
        <source>Rescanning...</source>
        <translation>Nouvelle analyse...</translation>
    </message>
    <message>
        <source>Done loading</source>
        <translation>Chargement terminé</translation>
    </message>
    </context>
</TS>